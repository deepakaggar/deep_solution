package output;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Output {

	@SuppressWarnings({"unchecked", "rawtypes" })
	public static void main(String[] args) throws IOException {
		FileWriter fr = new FileWriter(new File("src/output/output.txt"));
		BufferedReader br = new BufferedReader(new InputStreamReader(Output.class.getClassLoader().getResourceAsStream("output/person_wine_3.txt")));
		Set<String> persons = new HashSet<String>(1000);
		Set<String> wines = new HashSet<String>(10000);
		String line = "";
		while((line = br.readLine())!=null){
			String s[] =line.split("\\s+");
			persons.add(s[0]);
			wines.add(s[1]);
		}
		List<String> personslist = persons.stream().collect(Collectors.toList());
		List<String> wineslist = wines.stream().collect(Collectors.toList());
		List<Bean> outputList = new ArrayList<Bean>();
		for (int i = 0; i < personslist.size(); i++) {
			Bean bean = new Bean(personslist.get(i), wineslist.get(i));
			outputList.add(bean);
		}
		for (int i = 0; i < personslist.size(); i++) {
			int winecounter = personslist.size()+i+1;
			Bean bean = new Bean(personslist.get(i), wineslist.get(winecounter));
			outputList.add(bean);
		}
		for (int i = 0; i < personslist.size(); i++) {
			int winecounter = (2*personslist.size())+i+1;
			Bean bean = new Bean(personslist.get(i), wineslist.get(winecounter));
			outputList.add(bean);
		}
		HashMap<String, List<Bean>> hm = (HashMap) outputList.stream().collect(Collectors.groupingBy(Bean::getPerson));
		List<String> result = new ArrayList(hm.keySet());
		List<Integer> numberList = new ArrayList<>();
		for (int i = 0; i < result.size(); i++) {
			String[] numbers = result.get(i).split("\\D+");
			numberList.add(Integer.parseInt(numbers[1]));
		}
		Collections.sort(numberList);
		try {
			fr.write("The number of wine bottles sold in aggregate with my solution are "+(numberList.size()*3)+"\n");
			for (int i = 0; i < numberList.size(); i++) {
				String name = result.get(i).split("\\d+")[0];
				for(int j=0;j<hm.get(name+numberList.get(i)).size();j++){
					fr.write(name+numberList.get(i)+" "+hm.get(name+numberList.get(i)).get(j)+"\n");
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
