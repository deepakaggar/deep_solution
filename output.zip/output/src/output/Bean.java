package output;

public class Bean {
	private String person;
	private String wine;
	public String getPerson() {
		return person;
	}
	public void setPerson(String person) {
		this.person = person;
	}
	public String getWine() {
		return wine;
	}
	public void setWine(String wine) {
		this.wine = wine;
	}
	public Bean(String person, String wine) {
		super();
		this.person = person;
		this.wine = wine;
	}
	@Override
	public String toString() {
		return wine;
	}



}
